n = input("Enter a string:")
s= n.upper()
for i in s:
    print(i,end = ' ')