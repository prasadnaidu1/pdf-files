# MonthlyExpenses
An individual can track his monthly expenses in the different category.
Can split bills with his friends for a trip/hangout/dinner outside.